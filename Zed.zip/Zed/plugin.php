<?php
/*
برای دیدن سورس های بیشتر به کانال ما سر بزنید :)

@heart_app
T.me/heart_app

هرگونه فروش سورس حرام است سورس اوپن شده و کاملا دیباگ شده توسط @mantal0_o بیاید با پخش این سورس از پول شویی و حروم خوری ملت همکاری کنیم
ربات محافظ گروه cli
*/
// ---
$admins = [
  781834893,
];
$web_url = "https://dunyialaa.000webhostapp.com/Zed/Zed";
$helper_id = 'Dunyialybot'; // ایدی ربات api
$support_id= '@Sudobyduny_bot'; // ایدی پشتیبان
// ---
$plugins = [
"tools",
"sudo",
"delete",
"send",
"help",
];
$cplug = count($plugins) - 1;
for($n=0; $n<=$cplug; $n++) {
  $pluginlist = "cli/".$plugins[$n].".php";
  include($pluginlist);
}
@$data=json_decode(file_get_contents('data.json'),true);
$power = $data['bot'];
unlink("MadelineProto.log");
/*
برای دیدن سورس های بیشتر به کانال ما سر بزنید :)

@heart_app
T.me/heart_app

گهرگونه فروش سورس حرام است سورس اوپن شده و کاملا دیباگ شده توسط @mantal0_o بیاید با پخش این سورس از پول شویی و حروم خوری ملت همکاری کنیم
ربات محافظ گروه cli
*/