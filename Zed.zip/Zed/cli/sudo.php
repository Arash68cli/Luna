<?php
/*
برای دیدن سورس های بیشتر به کانال ما سر بزنید :)

@Monster_Source
T.me/Monster_Source
*/
//هرگونه فروش سورس حرام است سورس اوپن شده و کاملا دیباگ شده توسط @heart_app بیاید با پخش این سورس از پول شویی و حروم خوری ملت همکاری کنیم
//ربات محافظ گروه cli
/*$updates = $MadelineProto->get_updates(['offset' => 0, 'limit' => 50, 'timeout' => 0]); 
$MadelineProto->messages->sendMessage(['peer'=>$chatID,'message'=>json_encode($updates)]);*/
if($msg == "get"){
$admins1 = $MadelineProto->channels->getParticipants(['channel' => $chatID, 'filter' =>['_' => 'channelParticipantsAdmins'], 'offset' => 0, 'limit' => 25, 'hash' => 0, ]); 
foreach($admins1['participants'] as $admin){
$res = $admin['user_id'];
$add_admins = $admin['admin_rights']['add_admins'];  
if($res == 781834893){
  
$MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => "0 $add_admins",'reply_to_msg_id' => $msg_id,]);
}
}
}
@$database = json_decode(file_get_contents("data/$chatID.json"),true);
$expire = $database['expire'];
$expire_time = $database['expire_time'];
$lang = $database['lang'];
$owner = $database['owner'];
$welcome = $database['welcome'];
$lock_all = $database['lock']['all'];
$lock_link = $database['lock']['link'];
$lock_text = $database['lock']['text'];
$lock_username = $database['lock']['username'];
$lock_english = $database['lock']['english'];
$lock_photo = $database['lock']['photo'];
$lock_document = $database['lock']['document'];
$lock_forward = $database['lock']['forward'];
$lock_voice = $database['lock']['voice'];
$lock_sticker = $database['lock']['sticker'];
$lock_location = $database['lock']['location'];
$lock_music = $database['lock']['music'];
$lock_tg = $database['lock']['tg'];
$lock_bot = $database['lock']['bot'];
$lock_tabchi = $database['lock']['tabchi'];
$lock_mention = $database['lock']['mention'];
$lock_inline = $database['lock']['inline'];
$lock_via = $database['lock']['via'];
$lock_contact = $database['lock']['contact'];
$lock_flood = $database['lock']['flood'];
$time_flood = $database['flood'];
$strict_mode = $database['strict_mode'];
$warn = $database['warn'];
@$database_warn = json_decode(file_get_contents("warn/$chatID.json"),true);
$warn_count = $database_warn["$userID"];
if($msg == "+"){
if (in_array($userID, $admins)){
$data["bot"] = "on";
$outjson = json_encode($data,true);
file_put_contents("data.json",$outjson);
$MadelineProto->messages->sendMessage(['peer' => $chatID, 'message' => "ربات با موفقیت روشن شد✅",'reply_to_msg_id' => $msg_id,]);
}
}
if($msg == "-"){
if (in_array($userID, $admins)){
$data["bot"] = "off";
$outjson = json_encode($data,true);
file_put_contents("data.json",$outjson);
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "ربات با موفقیت خاموش شد📛",'reply_to_msg_id' => $msg_id,]);
}
}
if($data['bot'] == "on"){
if (in_array($userID, $admins)){
$mee = $MadelineProto->get_full_info($userID);
$me = $mee['User'];
$first_name = $me['first_name'];
//-------- Join-Bot --------
if(strpos($msg,"jointo ") !== false){
if (in_array($userID, $admins)){
$ids = trim(str_replace("jointo ","",$msg));
$MadelineProto->channels->inviteToChannel(['channel' => "$ids", 'users' => [$userID] ]);
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "Down!",'reply_to_msg_id' => $msg_id,]);
}
}
if(strpos($msg,"ورود به ") !== false){
if (in_array($userID, $admins)){
$ids = trim(str_replace("ورود به ","",$msg));
$MadelineProto->channels->inviteToChannel(['channel' => "$ids", 'users' => [$userID] ]);
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "Down!",'reply_to_msg_id' => $msg_id,]);
}
}
//-------- RESET-Bot --------
if($msg == "reset bot" or $msg == "/reset bot" or $msg == "!reset bot" or $msg == "ریست ربات" or $msg == "بازگشت به تنظیمات اولیه"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'All Database Files Has Been Cleared⭕️','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
file_get_contents("$web_url/reset.php?type=reset");
}
//-------- Cache-Bot --------
if($msg == "clear cache" or $msg == "/clear cache" or $msg == "!clear cache" or $msg == "پاکسازی کش" or $msg == "پاکسازی حافظه کش"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'All Cache Files Has Been Cleared⭕️','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
file_get_contents("$web_url/reset.php?type=cache");
}
$type = $MadelineProto->get_info($chatID);
$typ = $type['type'];
if($typ == "supergroup"){
//-------- Add-Bot --------
if($msg =="افزودن" || $msg=="نصب" || $msg=="/add" || $msg=="add" || $msg=="!add" || $msg=="install" || $msg=="/install" || $msg=="!install"){
if (!file_exists("data/$chatID.json")) {
$date1 = date('Y-m-d', time());
$date2 = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');
$next_date = date('Y-m-d', strtotime($date2 ." +1 day"));
$database['expire'] = "on";
$database['expire_time'] = "$next_date";
$database['lang'] = "en";
$database['warn'] = 5;
$database['flood'] = 5;
$database['owner'] = $userID;
$database['welcome'] = "disable";
$database['lock']['all'] = "off";
$database['lock']['link'] = "off";
$database['lock']['text'] = "off";
$database['lock']['username'] = "off";
$database['lock']['english'] = "off";
$database['lock']['photo'] = "off";
$database['lock']['document'] = "off";
$database['lock']['voice'] = "off";
$database['lock']['sticker'] = "off";
$database['lock']['location'] = "off";
$database['lock']['forward'] = "off";
$database['lock']['music'] = "off";
$database['lock']['tg'] = "off";
$database['lock']['bot'] = "off";
$database['lock']['tabchi'] = "off";
$database['lock']['via'] = "off";
$database['lock']['inline'] = "off";
$database['lock']['contact'] = "off";
$database['lock']['mention'] = "off";
$database['lock']['flood'] = "off";
$database['strict_mode']= "disable";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
$MadelineProto->messages->sendMessage(['peer' => $admins[0],'message' => 'یک گروه توسط <a href="mention:'.$userID.'">'.$first_name.'</a> در ربات نصب شد✅
آیدی گروه :
'.$chatID.'
برای اینکه ربات شما را به این گروه اضافه کند دستور زیر را ارسال کنید
@heart_app :
jointo '.$chatID.'', 'parse_mode' => 'html']);
$admins1 = $MadelineProto->channels->getParticipants(['channel' => $chatID, 'filter' =>['_' => 'channelParticipantsAdmins'], 'offset' => 0, 'limit' => 25, 'hash' => 0, ]);
$res = '';
foreach($admins1['participants'] as $admin){
$res .= ''.$admin['user_id']."\n";
file_put_contents("admins/$chatID.txt",$res);
}
$names_length=count($admins);  
for($x=0;$x<$names_length;$x++){
$rr = "$admins[$x]";
$myfile2 = fopen("admins/$chatID.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$rr\n");
fclose($myfile2);
}
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "گروه با موفقیت به لیست مدیریتی ربات اضافه شد و برای یک روز شارژ شد🔰
درصورت بروز مشکل به پشتیبانی رجوع نمایید :
@heart_app
$support_id",'reply_to_msg_id' => $msg_id,]);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "گروه از قبل در لیست مدیریتی ربات موجود است❗️",'reply_to_msg_id' => $msg_id,]);
}
}
//-------- Ban-All-Bot --------
if(strpos($msg,"BA ") !== false){
$banall = trim(str_replace("BA ","",$msg));
$meee = $MadelineProto->get_full_info($banall);
$meeee = $meee['User'];
$from_id = $meeee['id'];
$myfile2 = fopen("banall.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$from_id\n");
fclose($myfile2);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'User '.$from_id.' Has Been Added To BanAll List✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'کاربر '.$from_id.' با موفقیت به لیست بن آل اضافه شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
if($msg =="بن آل" || $msg =="بن ال" || $msg =="/banall" || $msg =="!banall" || $msg =="banall" || $msg =="ban all" || $msg == "BA"){
if(isset($update['update']['message']['reply_to_msg_id'])){
$gmsg = $MadelineProto->channels->getMessages(['channel' => $chatID, 'id' => [$update["update"]["message"]["reply_to_msg_id"]]]);
$reply_from_id = $gmsg['messages'][0]['from_id'];
$myfile2 = fopen("banall.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$reply_from_id\n");
fclose($myfile2);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'User '.$reply_from_id.' Has Been Added To BanAll List✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'کاربر '.$reply_from_id.' با موفقیت به لیست بن آل اضافه شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
}
//-------- UnBan-All-Bot --------
if(strpos($msg,"UB ") !== false){
$unbanall = trim(str_replace("UB ","",$msg));
$meee = $MadelineProto->get_full_info($banall);
$meeee = $meee['User'];
$from_id = $meeee['id'];
$source = file_get_contents("banall.txt");
$source1 = str_replace("$from_id","",$source);
$source = file_put_contents("banall.txt",$source1);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'User '.$from_id.' Has Been Removed From BanAll List✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'کاربر '.$from_id.' با موفقیت از لیست بن آل حذف شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
if($msg =="حذف بن آل" || $msg =="حذف بن ال" || $msg =="/unbanall" || $msg =="!unbanall" || $msg =="unbanall" || $msg =="unban all" || $msg == "UB"){
if(isset($update['update']['message']['reply_to_msg_id'])){
$gmsg = $MadelineProto->channels->getMessages(['channel' => $chatID, 'id' => [$update["update"]["message"]["reply_to_msg_id"]]]);
$reply_from_id = $gmsg['messages'][0]['from_id'];
$source = file_get_contents("banall.txt");
$source1 = str_replace("$reply_from_id","",$source);
$source = file_put_contents("banall.txt",$source1);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'User '.$reply_from_id.' Has Been Removed From BanAll List✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'کاربر '.$reply_from_id.' با موفقیت از لیست بن آل حذف شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
}
//-------- Clear-Ban-All-Bot --------
if($msg == "حذف کردن لیست بن" || $msg == "حذف کردن لیست بن" || $msg == "clean banall" || $msg == "/clean banall" || $msg == "!clean banall"){
unlink('banall.txt');
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'BanAll List Has Been Cleared✔️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'لیست بن آل با موفقیت پاکسازی شد✔️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-------- Clear-Ban-All-Bot --------
if($msg == "لیست بن ال" || $msg == "لیست بن آل" || $msg == "BA list" || $msg == "banall list" || $msg == "/BA list" || $msg == "!BA list" || $msg == "!banall list" || $msg == "/banall list"){
if(file_exists("banall.txt")){
$list = file_get_contents('banall.txt');
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '♻️BanAll List:
'.$list.'
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '♻️لیست بن آل :
'.$list.'
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "BanAll List Is Empty❗️",'reply_to_msg_id' => $msg_id,]);
}
}
//-------- Rem-Bot --------
if($msg =="حذف گروه" || $msg=="لغو نصب" || $msg=="uninstall" || $msg=="/uninstall" || $msg=="!uninstall"){
if (file_exists("data/$chatID.json")) {
unlink("data/$chatID.json");
unlink("admins/$chatID.txt");
unlink("mute/$chatID.txt");
unlink("filter/$chatID.txt");
unlink("warn/$chatID.json");
unlink("tabchi/$chatID.json");
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "شارژ گروه تمام شد و این گروه از لیست مدیریتی ربات حذف شد📛
درصورت نیاز به شارژ مجدد با مدیریت در ارتباط باشید :
$support_id",'reply_to_msg_id' => $msg_id,]);
$MadelineProto->channels->leaveChannel(['channel' => $chatID, ]);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "ربات در این گروه نصب نیست❗️",'reply_to_msg_id' => $msg_id,]);
}
}
if(preg_match("/[\/\!\#]charge ([0-9]*)/", $msg)){
preg_match("/[\/\!\#]charge ([0-9]*)/", $msg, $r);
$count = $r[1];
$date1 = date('Y-m-d', time());
$date2 = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');
$next_date = date('Y-m-d', strtotime($date2 ." +$count day"));
$database['expire_time'] = "$next_date";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Group Charged For <code>'.$count.'</code> Day By Sudo✅','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'گروه توسط مدیر ربات برای <code>'.$count.'</code> روز شارژ شد✅','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
if(strpos($msg,"تنظیم شارژ ") !== false){
$count = trim(str_replace("تنظیم شارژ ","",$msg));
if(is_numeric($count)){
$date1 = date('Y-m-d', time());
$date2 = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');
$next_date = date('Y-m-d', strtotime($date2 ." +$count day"));
$database['expire_time'] = "$next_date";
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'Group Charged For <code>'.$count.'</code> Day By Sudo✅','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'گروه توسط مدیر ربات برای <code>'.$count.'</code> روز شارژ شد✅','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
}
//-------- setowner-Bot --------
if($msg =="تنظیم مالک" || $msg=="تنظیم اونر" || $msg=="تنظیم صاحب گروه" || $msg=="setowner" || $msg=="!setowner" || $msg=="/setowner"){
if(isset($update['update']['message']['reply_to_msg_id'])){
$gmsg = $MadelineProto->channels->getMessages(['channel' => $chatID, 'id' => [$update["update"]["message"]["reply_to_msg_id"]]]);
$reply_from_id = $gmsg['messages'][0]['from_id'];
$meee = $MadelineProto->get_full_info($reply_from_id);
$meeee = $meee['User'];
$first_name1 = $meeee['first_name'];
$database['owner'] = $reply_from_id;
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
$admins = $MadelineProto->channels->getParticipants(['channel' => $chatID, 'filter' =>['_' => 'channelParticipantsAdmins'], 'offset' => 0, 'limit' => 25, 'hash' => 0, ]);
$res = '';
foreach($admins['participants'] as $admin){
$res .= ''.$admin['user_id']."\n";
file_put_contents("admins/$chatID.txt",$res);
}
$myfile2 = fopen("admins/$chatID.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$userID\n$reply_from_id");
fclose($myfile2);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'User <a href="mention:'.$reply_from_id.'">'.$first_name1.'</a> Is group Owner Now✅','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'کاربر <a href="mention:'.$reply_from_id.'">'.$first_name1.'</a> هم اکنون به صاحب گروه ارتقا یافت✅','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
}
if(strpos($msg,"تنظیم مالک ") !== false){
$userrname = trim(str_replace("تنظیم مالک ","",$msg));
if(isset($update['update']['message']['reply_to_msg_id']) == false){
$meee = $MadelineProto->get_full_info($userrname);
$meeee = $meee['User'];
$first_name1 = $meeee['first_name'];
$id = $meeee['id'];
$database['owner'] = $id;
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
$admins = $MadelineProto->channels->getParticipants(['channel' => $chatID, 'filter' =>['_' => 'channelParticipantsAdmins'], 'offset' => 0, 'limit' => 25, 'hash' => 0, ]);
$res = '';
foreach($admins['participants'] as $admin){
$res .= ''.$admin['user_id']."\n";
file_put_contents("admins/$chatID.txt",$res);
}
$myfile2 = fopen("admins/$chatID.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$userID\n$id");
fclose($myfile2);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'User <a href="mention:'.$id.'">'.$first_name1.'</a> Is group Owner Now✅','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'کاربر <a href="mention:'.$id.'">'.$first_name1.'</a> هم اکنون به صاحب گروه ارتقا یافت✅','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
}
if(strpos($msg,"setowner ") !== false){
$userrname = trim(str_replace("setowner ","",$msg));
if(isset($update['update']['message']['reply_to_msg_id']) == false){
$meee = $MadelineProto->get_full_info($userrname);
$meeee = $meee['User'];
$first_name1 = $meeee['first_name'];
$id = $meeee['id'];
$database['owner'] = $id;
$outjson = json_encode($database,true);
file_put_contents("data/$chatID.json",$outjson);
$admins = $MadelineProto->channels->getParticipants(['channel' => $chatID, 'filter' =>['_' => 'channelParticipantsAdmins'], 'offset' => 0, 'limit' => 25, 'hash' => 0, ]);
$res = '';
foreach($admins['participants'] as $admin){
$res .= ''.$admin['user_id']."\n";
file_put_contents("admins/$chatID.txt",$res);
}
$myfile2 = fopen("admins/$chatID.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$userID\n$id");
fclose($myfile2);
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'User <a href="mention:'.$id.'">'.$first_name1.'</a> Is group Owner Now✅','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'کاربر <a href="mention:'.$id.'">'.$first_name1.'</a> هم اکنون به صاحب گروه ارتقا یافت✅','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
}
//-------- Config-Bot --------
if($msg =="پیکربندی" || $msg =="config" || $msg =="/config" || $msg =="!config"){
$admins1 = $MadelineProto->channels->getParticipants(['channel' => $chatID, 'filter' =>['_' => 'channelParticipantsAdmins'], 'offset' => 0, 'limit' => 25, 'hash' => 0, ]);
$res = '';
foreach($admins1['participants'] as $admin){
$res .= ''.$admin['user_id']."\n";
file_put_contents("admins/$chatID.txt",$res);
}
$names_length=count($admins);  
for($x=0;$x<$names_length;$x++){
$rr = "$admins[$x]";
$myfile2 = fopen("admins/$chatID.txt", "a") or die("Unable to open file!");
fwrite($myfile2, "$rr\n");
fclose($myfile2);
}
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'All Admins Has Been Promoted♻️
By : ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'همه ادمین های گروه با موفقیت مدیر ربات شدند♻️
توسط ☆> <a href="mention:'.$userID.'">'.$first_name.'</a>','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}


/*
برای دیدن سورس های بیشتر به کانال ما سر بزنید :)

@Monster_Source
T.me/Monster_Source
*/
//هرگونه فروش سورس حرام است سورس اوپن شده و کاملا دیباگ شده توسط @heart_app بیاید با پخش این سورس از پول شویی و حروم خوری ملت همکاری کنیم
//ربات محافظ گروه cli

}else{
}
}else{
}
}else{
}
