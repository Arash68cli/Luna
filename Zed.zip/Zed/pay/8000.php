<?php
//هرگونه فروش سورس حرام است سورس اوپن شده و کاملا دیباگ شده توسط @mantal0_o بیاید با پخش این سورس از پول شویی و حروم خوری ملت همکاری کنیم
//ربات محافظ گروه cli
$MerchantID = '@Mantal0_o';
$Amount = 8000;
$days = 60;
$Authority = $_GET['Authority'];
$GpId = $_GET['id'];
if ($_GET['Status'] == 'OK'){
$client = new SoapClient('https://t.me/Mantal0_o', ['encoding' => 'UTF-8']);
$result = $client->PaymentVerification(
[
'MerchantID' => $MerchantID,
'Authority' => $Authority,
'Amount' => $Amount,
]
);

if ($result->Status == 100){
$date1 = date('Y-m-d', time());
$date2 = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');
$next_date = date('Y-m-d', strtotime($date2 ." +$days day"));
@$database = json_decode(file_get_contents("../data/$GpId.json"),true);
$database['expire_time'] = "$next_date";
$database['expire'] = "on";
$outjson = json_encode($database,true);
file_put_contents("../data/$GpId.json",$outjson);
echo 'پرداخت انجام شد و گروه شما با موفقیت شارژ شد🔵';
} else {
echo 'پرداخت شما قبلا ثبت شده است';
}
} else {
echo 'پرداخت انجام نشد';
}
//هرگونه فروش سورس حرام است سورس اوپن شده و کاملا دیباگ شده توسط @mantal0_o بیاید با پخش این سورس از پول شویی و حروم خوری ملت همکاری کنیم
//ربات محافظ گروه cli
?>
