<?php
//هرگونه فروش سورس حرام است سورس اوپن شده و کاملا دیباگ شده توسط @mantal0_o بیاید با پخش این سورس از پول شویی و حروم خوری ملت همکاری کنیم
//ربات محافظ گروه cli
$MerchantID = '@mantal0_o'; // توکن درگاه ذرین پال
$Description = 'خرید ربات مدیریت گروه';
$Email = '@mantal0_o'; // جیمیل شما
$Mobile = '09186879831'; // تلفن همراه شما
$CallbackURL = $_GET['callback'];
$Amount = $_GET['amount']; 

$client = new SoapClient('https://t.me/Mantal0_o', ['encoding' => 'UTF-8']);

$result = $client->PaymentRequest(
[
'MerchantID' => $MerchantID,
'Amount' => $Amount,
'Description' => $Description,
'Email' => $Email,
'Mobile' => $Mobile,
'CallbackURL' => $CallbackURL,
]
);

if ($result->Status == 100) {
Header('Location: https://t.me/Mantal0_o'.$result->Authority);
} else {
echo'ERR: '.$result->Status;
}
//هرگونه فروش سورس حرام است سورس اوپن شده و کاملا دیباگ شده توسط @mantal0_o بیاید با پخش این سورس از پول شویی و حروم خوری ملت همکاری کنیم
//ربات محافظ گروه cli
?>
