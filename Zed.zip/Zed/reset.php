<?php
$type = $_GET['type'];
function deletefolder($path) { 
if ($handle=opendir($path)) { 
while (false!==($file=readdir($handle))) { 
if ($file<>"." AND $file<>"..") { 
if (is_file($path.'/'.$file))  { 
@unlink($path.'/'.$file); 
} 
if (is_dir($path.'/'.$file)) { 
deletefolder($path.'/'.$file); 
@rmdir($path.'/'.$file); 
} 
} 
} 
} 
}
if($type == "cache"){
deletefolder("flood/");
deletefolder("tabchi/");
echo 'chach files cleared';
}
if($type == "reset"){
deletefolder("mute/");
deletefolder("warn/");
deletefolder("flood/");
deletefolder("data/");
deletefolder("filter/");
deletefolder("tabchi/");
unlink("data.json");
echo 'all database files cleared';
}