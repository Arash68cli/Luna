<?php
/*
neXtgig.ir
neXtbot.ir
*/
$MerchantID = '@NEXTBOTchannel'; // توکن درگاه ذرین پال
$Description = 'خرید ربات مدیریت گروه';
$Email = '@NEXTBOTchannel'; // جیمیل شما
$Mobile = '01'; // تلفن همراه شما
$CallbackURL = $_GET['callback'];
$Amount = $_GET['amount']; 

$client = new SoapClient('https://t.me/NEXTBOTchannel', ['encoding' => 'UTF-8']);

$result = $client->PaymentRequest(
[
'MerchantID' => $MerchantID,
'Amount' => $Amount,
'Description' => $Description,
'Email' => $Email,
'Mobile' => $Mobile,
'CallbackURL' => $CallbackURL,
]
);

if ($result->Status == 100) {
Header('Location: https://t.me/NEXTBOTchannel'.$result->Authority);
} else {
echo'ERR: '.$result->Status;
}
/*
@NEXTBOTchannel
https://t.me/NEXTBOTchannel
*/
?>
