<?php
/*
neXtbot.ir
devMic
*/
@$database = json_decode(file_get_contents("data/$chatID.json"),true);
$expire = $database['expire'];
$lang = $database['lang'];
$owner = $database['owner'];
$welcome = $database['welcome'];
$lock_all = $database['lock']['all'];
$lock_link = $database['lock']['link'];
$lock_text = $database['lock']['text'];
$lock_username = $database['lock']['username'];
$lock_english = $database['lock']['english'];
$lock_photo = $database['lock']['photo'];
$lock_document = $database['lock']['document'];
$lock_forward = $database['lock']['forward'];
$lock_voice = $database['lock']['voice'];
$lock_sticker = $database['lock']['sticker'];
$lock_location = $database['lock']['location'];
$lock_music = $database['lock']['music'];
$lock_tg = $database['lock']['tg'];
$lock_bot = $database['lock']['bot'];
$lock_tabchi = $database['lock']['tabchi'];
$lock_mention = $database['lock']['mention'];
$lock_inline = $database['lock']['inline'];
$lock_via = $database['lock']['via'];
$lock_contact = $database['lock']['contact'];
$lock_flood = $database['lock']['flood'];
$time_flood = $database['flood'];
$strict_mode = $database['strict_mode'];
$warn = $database['warn'];
@$database_warn = json_decode(file_get_contents("warn/$chatID.json"),true);
$warn_count = $database_warn["$userID"];
@$database_mute = json_decode(file_get_contents("mute/$chatID.json"),true);
$mute_time = $database_mute["$userID"]["time"];
if($data['bot'] == "on"){
@$admin_list = file_get_contents("admins/$chatID.txt");
$exp=explode("\n",$admin_list);
if(!in_array($userID,$exp)){
if (!in_array($userID,$admins) ){
if($userID !== $owner){
$type = $MadelineProto->get_info($chatID);
$typ = $type['type'];
if($typ == "supergroup"){
if($expire == "on"){
$mee = $MadelineProto->get_full_info($userID);
$me = $mee['User'];
$first_name = $me['first_name'];
//-- Delete Link --//
if($lock_link == "on"){
if(preg_match("/^(.*)([Hh]ttp|[Hh]ttps|t.me)(.*)|([Hh]ttp|[Hh]ttps|t.me)(.*)|(.*)([Hh]ttp|[Hh]ttps|t.me)|(.*)[Tt]elegram.me(.*)|[Tt]elegram.me(.*)|(.*)[Tt]elegram.me|(.*)[Tt].me(.*)|[Tt].me(.*)|(.*)[Tt].me/", $msg)) {
if($strict_mode == "enable"){
$channelBannedRights = ['_' => 'channelBannedRights', 'view_messages' => true, 'send_messages' => false, 'send_media' => false, 'send_stickers' => false, 'send_gifs' => false, 'send_games' => false, 'send_inline' => false, 'embed_links' => false, 'until_date' => 0];
$MadelineProto->channels->editBanned([
'channel'=> $chatID,
'user_id'=> $userID,
'banned_rights' => $channelBannedRights]);
$dalil = "ارسال متن حاوی لینک";
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'کاربر <a href="mention:'.$userID.'">'.$first_name.'</a> بدلیل '.$dalil.' از گروه اخراج شد📛','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
$MadelineProto->channels->deleteMessages(['channel' => $chatID, 'id' => [$msg_id,]]);
}
}
//-- Delete Username --//
if($lock_username == "on"){
if(strpos($msg,"@") !== false){
if($strict_mode == "enable"){
$channelBannedRights = ['_' => 'channelBannedRights', 'view_messages' => true, 'send_messages' => false, 'send_media' => false, 'send_stickers' => false, 'send_gifs' => false, 'send_games' => false, 'send_inline' => false, 'embed_links' => false, 'until_date' => 0];
$MadelineProto->channels->editBanned([
'channel'=> $chatID,
'user_id'=> $userID,
'banned_rights' => $channelBannedRights]);
$dalil = "ارسال متن حاوی یوزرنیم";
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'کاربر <a href="mention:'.$userID.'">'.$first_name.'</a> بدلیل '.$dalil.' از گروه اخراج شد📛','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
$MadelineProto->channels->deleteMessages(['channel' => $chatID, 'id' => [$msg_id,]]);
}
}
//-- Delete Muted User --//
if($mute_time == "0"){
if(isset($update['update']['message']['media']['document']) or isset($update['update']['message']['media']['photo']) or $msg !== false){
$MadelineProto->channels->deleteMessages(['channel' => $chatID, 'id' => [$msg_id,]]);
}
}
//-- Ban All --//
@$banall_list = file_get_contents("banall.txt");
$exp_banall=explode("\n",$banall_list);
if(in_array($userID,$exp_banall)){
$MadelineProto->channels->deleteUserHistory(['channel' => $chatID, 'user_id' => $userID, ]);
$channelBannedRights = ['_' => 'channelBannedRights', 'view_messages' => true, 'send_messages' => false, 'send_media' => false, 'send_stickers' => false, 'send_gifs' => false, 'send_games' => false, 'send_inline' => false, 'embed_links' => false, 'until_date' => 0];
$MadelineProto->channels->editBanned([
'channel'=> $chatID,
'user_id'=> $userID,
'banned_rights' => $channelBannedRights]);
$dalil = "بن آل شدن توسط صاحب ربات";
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'کاربر <a href="mention:'.$userID.'">'.$first_name.'</a> بدلیل '.$dalil.' از گروه اخراج شد📛','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	

}
//-- Delete Text --//
if($lock_text == "on"){
if($msg !== false){
if($strict_mode == "enable"){
$channelBannedRights = ['_' => 'channelBannedRights', 'view_messages' => true, 'send_messages' => false, 'send_media' => false, 'send_stickers' => false, 'send_gifs' => false, 'send_games' => false, 'send_inline' => false, 'embed_links' => false, 'until_date' => 0];
$MadelineProto->channels->editBanned([
'channel'=> $chatID,
'user_id'=> $userID,
'banned_rights' => $channelBannedRights]);
$dalil = "ارسال متن";
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'کاربر <a href="mention:'.$userID.'">'.$first_name.'</a> بدلیل '.$dalil.' از گروه اخراج شد📛','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
$MadelineProto->channels->deleteMessages(['channel' => $chatID, 'id' => [$msg_id,]]);
}
}
//-- Delete English --//
if($lock_english == "on"){
if($msg !== false){
$english = strlen($msg) == mb_strlen($msg,'utf-8');
if ($english !== false) {
if($strict_mode == "enable"){
$channelBannedRights = ['_' => 'channelBannedRights', 'view_messages' => true, 'send_messages' => false, 'send_media' => false, 'send_stickers' => false, 'send_gifs' => false, 'send_games' => false, 'send_inline' => false, 'embed_links' => false, 'until_date' => 0];
$MadelineProto->channels->editBanned([
'channel'=> $chatID,
'user_id'=> $userID,
'banned_rights' => $channelBannedRights]);
$dalil = "ارسال متن حاوی کلمات انگلیسی";
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'کاربر <a href="mention:'.$userID.'">'.$first_name.'</a> بدلیل '.$dalil.' از گروه اخراج شد📛','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
$MadelineProto->channels->deleteMessages(['channel' => $chatID, 'id' => [$msg_id,]]);
}
}
}
//-- Delete Photo --//
if($lock_photo == "on"){
if(isset($update['update']['message']['media']['photo'])){
if($strict_mode == "enable"){
$channelBannedRights = ['_' => 'channelBannedRights', 'view_messages' => true, 'send_messages' => false, 'send_media' => false, 'send_stickers' => false, 'send_gifs' => false, 'send_games' => false, 'send_inline' => false, 'embed_links' => false, 'until_date' => 0];
$MadelineProto->channels->editBanned([
'channel'=> $chatID,
'user_id'=> $userID,
'banned_rights' => $channelBannedRights]);
$dalil = "ارسال عکس";
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'کاربر <a href="mention:'.$userID.'">'.$first_name.'</a> بدلیل '.$dalil.' از گروه اخراج شد📛','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
$MadelineProto->channels->deleteMessages(['channel' => $chatID, 'id' => [$msg_id,]]);
}
}
//-- Delete document --//
if($lock_document == "on"){
if(isset($update['update']['message']['media']['document'])){
if($strict_mode == "enable"){
$channelBannedRights = ['_' => 'channelBannedRights', 'view_messages' => true, 'send_messages' => false, 'send_media' => false, 'send_stickers' => false, 'send_gifs' => false, 'send_games' => false, 'send_inline' => false, 'embed_links' => false, 'until_date' => 0];
$MadelineProto->channels->editBanned([
'channel'=> $chatID,
'user_id'=> $userID,
'banned_rights' => $channelBannedRights]);
$dalil = "ارسال رسانه";
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'کاربر <a href="mention:'.$userID.'">'.$first_name.'</a> بدلیل '.$dalil.' از گروه اخراج شد📛','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
$MadelineProto->channels->deleteMessages(['channel' => $chatID, 'id' => [$msg_id,]]);
}
}
//-- Delete All --//
if($lock_all == "on"){
if(isset($update['update']['message']['media']['document']) or isset($update['update']['message']['media']['photo']) or $msg !== false){
$MadelineProto->channels->deleteMessages(['channel' => $chatID, 'id' => [$msg_id,]]);
}
}
//-- Delete Voice --//
if($lock_voice == "on"){
if($update['update']['message']['media']['document']['attributes']['0']['voice'] == "true"){
if($strict_mode == "enable"){
$channelBannedRights = ['_' => 'channelBannedRights', 'view_messages' => true, 'send_messages' => false, 'send_media' => false, 'send_stickers' => false, 'send_gifs' => false, 'send_games' => false, 'send_inline' => false, 'embed_links' => false, 'until_date' => 0];
$MadelineProto->channels->editBanned([
'channel'=> $chatID,
'user_id'=> $userID,
'banned_rights' => $channelBannedRights]);
$dalil = "ارسال ویس";
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'کاربر <a href="mention:'.$userID.'">'.$first_name.'</a> بدلیل '.$dalil.' از گروه اخراج شد📛','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
$MadelineProto->channels->deleteMessages(['channel' => $chatID, 'id' => [$msg_id,]]);
}
}
//-- Delete forward --//
if($lock_forward == "on"){
if($update['update']['message']['fwd_from']['_'] == "messageFwdHeader"){
if($strict_mode == "enable"){
$channelBannedRights = ['_' => 'channelBannedRights', 'view_messages' => true, 'send_messages' => false, 'send_media' => false, 'send_stickers' => false, 'send_gifs' => false, 'send_games' => false, 'send_inline' => false, 'embed_links' => false, 'until_date' => 0];
$MadelineProto->channels->editBanned([
'channel'=> $chatID,
'user_id'=> $userID,
'banned_rights' => $channelBannedRights]);
$dalil = "فروارد کردن پیام";
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'کاربر <a href="mention:'.$userID.'">'.$first_name.'</a> بدلیل '.$dalil.' از گروه اخراج شد📛','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
$MadelineProto->channels->deleteMessages(['channel' => $chatID, 'id' => [$msg_id,]]);
}
}
//-- Delete sticker --//
if($lock_sticker == "on"){
if($update['update']['message']['media']['document']['attributes']['1']['alt'] !== null){
if($strict_mode == "enable"){
$channelBannedRights = ['_' => 'channelBannedRights', 'view_messages' => true, 'send_messages' => false, 'send_media' => false, 'send_stickers' => false, 'send_gifs' => false, 'send_games' => false, 'send_inline' => false, 'embed_links' => false, 'until_date' => 0];
$MadelineProto->channels->editBanned([
'channel'=> $chatID,
'user_id'=> $userID,
'banned_rights' => $channelBannedRights]);
$dalil = "ارسال استیکر";
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'کاربر <a href="mention:'.$userID.'">'.$first_name.'</a> بدلیل '.$dalil.' از گروه اخراج شد📛','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
$MadelineProto->channels->deleteMessages(['channel' => $chatID, 'id' => [$msg_id,]]);
}
}
//-- Delete location --//
if($lock_location == "on"){
if($update['update']['message']['media']['geo']['long'] !== null){
if($strict_mode == "enable"){
$channelBannedRights = ['_' => 'channelBannedRights', 'view_messages' => true, 'send_messages' => false, 'send_media' => false, 'send_stickers' => false, 'send_gifs' => false, 'send_games' => false, 'send_inline' => false, 'embed_links' => false, 'until_date' => 0];
$MadelineProto->channels->editBanned([
'channel'=> $chatID,
'user_id'=> $userID,
'banned_rights' => $channelBannedRights]);
$dalil = "ارسال موقعیت مکانی";
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'کاربر <a href="mention:'.$userID.'">'.$first_name.'</a> بدلیل '.$dalil.' از گروه اخراج شد📛','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
$MadelineProto->channels->deleteMessages(['channel' => $chatID, 'id' => [$msg_id,]]);
}
}
//-- Delete Mute Time --//
if($mute_time !== "0" and $mute_time !== null and $mute_time !== ''){
date_default_timezone_set('Asia/Tehran');
$time = time();
$time2 = date("g:i:s", $time);
if($time2 < $mute_time){
$MadelineProto->channels->deleteMessages(['channel' => $chatID, 'id' => [$msg_id,]]);
}else{
$database_mute["$userID"]["time"] = '';
$outjson = json_encode($database_mute,true);
file_put_contents("mute/$chatID.json",$outjson);
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => '<a href="mention:'.$userID.'">'.$first_name.'</a>
شما از حالت سکوت خارج شدید و مجاز به چت هستید📍','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
//-- Delete Bot --//
if($lock_bot == "on"){
if($update['update']['message']['action']['_'] == "messageActionChatAddUser"){
$botid = $update['update']['message']['action']['users']['0'];
$get_full = $MadelineProto->get_full_info($botid);
$typeuser = $get_full['type'];
if($typeuser == "bot"){
$channelBannedRights = ['_' => 'channelBannedRights', 'view_messages' => true, 'send_messages' => true, 'send_media' => true, 'send_stickers' => true, 'send_gifs' => true, 'send_games' => true, 'send_inline' => true, 'embed_links' => true, 'until_date' => 0];
$MadelineProto->channels->editBanned(['channel' => $chatID, 'user_id' => $botid, 'banned_rights' => $channelBannedRights, ]);
}
}
}
//-- Delete Music --//
if($lock_music == "on"){
if($update['update']['message']['media']['document']['attributes']['0']['voice'] !== "true" and $update['update']['message']['media']['document']['attributes']['0']['title'] !== null){
if($strict_mode == "enable"){
$channelBannedRights = ['_' => 'channelBannedRights', 'view_messages' => true, 'send_messages' => false, 'send_media' => false, 'send_stickers' => false, 'send_gifs' => false, 'send_games' => false, 'send_inline' => false, 'embed_links' => false, 'until_date' => 0];
$MadelineProto->channels->editBanned([
'channel'=> $chatID,
'user_id'=> $userID,
'banned_rights' => $channelBannedRights]);
$dalil = "ارسال موزیک";
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'کاربر <a href="mention:'.$userID.'">'.$first_name.'</a> بدلیل '.$dalil.' از گروه اخراج شد📛','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
$MadelineProto->channels->deleteMessages(['channel' => $chatID, 'id' => [$msg_id,]]);
}
}
//-- Delete Mention --//
if($lock_mention == "on"){
if($update['update']['message']['entities']['0']['_'] == "messageEntityMentionName"){
if($strict_mode == "enable"){
$channelBannedRights = ['_' => 'channelBannedRights', 'view_messages' => true, 'send_messages' => false, 'send_media' => false, 'send_stickers' => false, 'send_gifs' => false, 'send_games' => false, 'send_inline' => false, 'embed_links' => false, 'until_date' => 0];
$MadelineProto->channels->editBanned([
'channel'=> $chatID,
'user_id'=> $userID,
'banned_rights' => $channelBannedRights]);
$dalil = "ارسال متن حاوی منشن";
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'کاربر <a href="mention:'.$userID.'">'.$first_name.'</a> بدلیل '.$dalil.' از گروه اخراج شد📛','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
$MadelineProto->channels->deleteMessages(['channel' => $chatID, 'id' => [$msg_id,]]);
}
}
//-- Delete Via --//
if($lock_via == "on"){
if($update['update']['message']['via_bot_id'] !== null){
if($strict_mode == "enable"){
$channelBannedRights = ['_' => 'channelBannedRights', 'view_messages' => true, 'send_messages' => false, 'send_media' => false, 'send_stickers' => false, 'send_gifs' => false, 'send_games' => false, 'send_inline' => false, 'embed_links' => false, 'until_date' => 0];
$MadelineProto->channels->editBanned([
'channel'=> $chatID,
'user_id'=> $userID,
'banned_rights' => $channelBannedRights]);
$dalil = "ارسال فراخوانی";
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'کاربر <a href="mention:'.$userID.'">'.$first_name.'</a> بدلیل '.$dalil.' از گروه اخراج شد📛','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
$MadelineProto->channels->deleteMessages(['channel' => $chatID, 'id' => [$msg_id,]]);
}
}
//-- Delete inline --//
if($lock_inline == "on"){
if($update['update']['message']['reply_markup']['rows'] !== null){
if($strict_mode == "enable"){
$channelBannedRights = ['_' => 'channelBannedRights', 'view_messages' => true, 'send_messages' => false, 'send_media' => false, 'send_stickers' => false, 'send_gifs' => false, 'send_games' => false, 'send_inline' => false, 'embed_links' => false, 'until_date' => 0];
$MadelineProto->channels->editBanned([
'channel'=> $chatID,
'user_id'=> $userID,
'banned_rights' => $channelBannedRights]);
$dalil = "ارسال متن حاوی دکمه شیشه ای";
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'کاربر <a href="mention:'.$userID.'">'.$first_name.'</a> بدلیل '.$dalil.' از گروه اخراج شد📛','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
$MadelineProto->channels->deleteMessages(['channel' => $chatID, 'id' => [$msg_id,]]);
}
}
//-- Delete contact --//
if($lock_contact == "on"){
if($update['update']['message']['media']['_'] == "messageMediaContact"){
if($strict_mode == "enable"){
$channelBannedRights = ['_' => 'channelBannedRights', 'view_messages' => true, 'send_messages' => false, 'send_media' => false, 'send_stickers' => false, 'send_gifs' => false, 'send_games' => false, 'send_inline' => false, 'embed_links' => false, 'until_date' => 0];
$MadelineProto->channels->editBanned([
'channel'=> $chatID,
'user_id'=> $userID,
'banned_rights' => $channelBannedRights]);
$dalil = "ارسال متن حاوی دکمه شیشه ای";
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'کاربر <a href="mention:'.$userID.'">'.$first_name.'</a> بدلیل '.$dalil.' از گروه اخراج شد📛','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
$MadelineProto->channels->deleteMessages(['channel' => $chatID, 'id' => [$msg_id,]]);
}
}
//-- Filter Words --//
if(isset($update['update']['message']['message'])){
$listfilter = file_get_contents("filter/$chatID.txt");
$getfilter=explode("\n",$listfilter);
if($getfilter != ""){
foreach($getfilter as $key){
try{
if(strpos($msg,$key)!==false) {
$MadelineProto->channels->deleteMessages(['channel' => $chatID, 'id' => [$msg_id]]);	}
}catch(Exception $e){
}}}}
//-- Flood Lock --//
if($lock_flood == "on"){
$timing = date("Y-m-d-h-i-sa");
$timing = str_replace("am","",$timing);
$metti_khan = file_get_contents("flood/$timing-$userID.txt");
$timing_spam = $metti_khan+1;
file_put_contents("flood/$timing-$userID.txt","$timing_spam");
$metti_khan2 = file_get_contents("flood/$timing-$userID.txt");
if($metti_khan2 >= $time_flood){
if($strict_mode == "enable"){
$channelBannedRights = ['_' => 'channelBannedRights', 'view_messages' => true, 'send_messages' => false, 'send_media' => false, 'send_stickers' => false, 'send_gifs' => false, 'send_games' => false, 'send_inline' => false, 'embed_links' => false, 'until_date' => 0];
$MadelineProto->channels->editBanned([
'channel'=> $chatID,
'user_id'=> $userID,
'banned_rights' => $channelBannedRights]);
$dalil = "ارسال پیام مکرر";
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'کاربر <a href="mention:'.$userID.'">'.$first_name.'</a> بدلیل '.$dalil.' از گروه اخراج شد📛','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
/*$MadelineProto->channels->deleteMessages(['channel' => $chatID, 'id' => [$msg_id,]]);*/
$MadelineProto->channels->deleteUserHistory(['channel' => $chatID, 'user_id' => $userID, ]);
}
}
if($lock_tabchi == "on"){
$datab = json_decode(file_get_contents("tabchi/$chatID.json"),true);
$muter = $datab["$userID"];
if($muter == "-"){
if($update['update']['message']['action']['_'] !== "messageActionChatJoinedByLink" and $update['update']['message']['action']['_'] !== "messageActionChatDeleteUser" and $update['update']['message']['action']['_'] !== "messageActionChatAddUser"){
$MadelineProto->channels->deleteUserHistory(['channel' => $chatID, 'user_id' => $userID, ]);
$channelBannedRights = ['_' => 'channelBannedRights', 'view_messages' => true, 'send_messages' => false, 'send_media' => false, 'send_stickers' => false, 'send_gifs' => false, 'send_games' => false, 'send_inline' => false, 'embed_links' => false, 'until_date' => 0];
$MadelineProto->channels->editBanned([
'channel'=> $chatID,
'user_id'=> $userID,
'banned_rights' => $channelBannedRights]);
$dalil = "عدم تایید هویت (شناسایی تبچی)";
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'کاربر <a href="mention:'.$userID.'">'.$first_name.'</a> بدلیل '.$dalil.' از گروه اخراج شد📛','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
}
if($lock_tabchi == "on"){
if($update['update']['message']['action']['_'] == "messageActionChatJoinedByLink" or $update['update']['message']['action']['_'] == "messageActionChatAddUser"){
if($update['update']['message']['action']['_'] == "messageActionChatJoinedByLink"){
$IdUser = $userID;
}
if($update['update']['message']['action']['_'] == "messageActionChatAddUser"){
$IdUser = $update['update']['message']['action']['users']['0'];
;
}
$datab = json_decode(file_get_contents("tabchi/$chatID.json"),true);
$muty = $datab["$IdUser"];
if($muty !== "+"){
$datab["$IdUser"] = "-";
$outjson = json_encode($datab,true);
file_put_contents("tabchi/$chatID.json",$outjson);
$messages_BotResults = $MadelineProto->messages->getInlineBotResults(['bot' => $helper_id, 'peer' => $chatID, 'query' => 'tabchi|'.$IdUser.'|'.$chatID.'', 'offset' => '0', ]);
$query_id = $messages_BotResults['query_id'];
$query_res_id = $messages_BotResults['results'][0]['id'];
$MadelineProto->messages->sendInlineBotResult(['silent' => true, 'background' => false, 'clear_draft' => true, 'peer' => $chatID, 'reply_to_msg_id' => $msg_id, 'query_id' => $query_id, 'id' => "$query_res_id", ]);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => 'هویت کاربر '.$IdUser.' از قبل در گروه تایید شده بود✅','reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);	
}
}
}




}else{
}
}else{
}
}else{
}
}else{
}
}else{
}
}else{
}
//-- Delete Tg --//
if($lock_tg == "on"){
if($update['update']['message']['action']['_'] == "messageActionChatJoinedByLink" or $update['update']['message']['action']['_'] == "messageActionChatDeleteUser" or $update['update']['message']['action']['_'] == "messageActionChatAddUser"){
$MadelineProto->channels->deleteMessages(['channel' => $chatID, 'id' => [$msg_id,]]);
}
}
/*
نکست بات انجمن پر از سورس های ربات تلگرام
@NEXTBOTchannel
https://t.me/NEXTBOTchannel
*/



