<?php
/*
@NEXTBOTchannel
https://t.me/NEXTBOTchannel
*/
@$database = json_decode(file_get_contents("data/$chatID.json"),true);
$expire = $database['expire'];
$lang = $database['lang'];
if($data['bot'] == "on"){
$type = $MadelineProto->get_info($chatID);
$typ = $type['type'];
if($typ == "supergroup"){
if($expire == "on"){
@$admin_list = file_get_contents("admins/$chatID.txt");
$exp=explode("\n",$admin_list);

if(in_array($userID,$exp)){
if($msg =="راهنما" || $msg=="/help" || $msg=="help" || $msg=="!help" || $msg=="h" || $msg=="H"){
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "❄️NEXTBOTchannel-AntiSpam | Help :

▪️<code>lockhelp</code>▪️  => راهنمای قفل ها
🔸🔹🔸🔹http://t.me/NEXTBOTchannel🔸🔹🔸🔹
▪️<code>managehelp</code>▪️ => راهنمای مدیریتی
🔸🔹🔸🔹http://t.me/NEXTBOTchannel🔸🔹🔸🔹
▪️<code>funhelp</code>▪️ => راهنمای عمومی
🔸🔹🔸🔹http://t.me/NEXTBOTchannel🔸🔹🔸🔹
▪️<code>cleanhelp</code>▪️ => راهنمای پاکسازی
🔸🔹🔸🔹http://t.me/NEXTBOTchannel🔸🔹🔸🔹
▪️<code>sudohelp</code>▪️ => راهنمای سودو
🌧🌧🌧🌧🌧🌧🌧🌧🌧🌧🌧
کانال ما :
@NEXTBOTchannel",'reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
$sentMessage = $MadelineProto->messages->sendMedia([
    'peer' => $chatID,
    'media' => [
        '_' => 'inputMediaUploadedDocument',
        'file' => 'Help.txt',
        'attributes' => [
            ['_' => 'documentAttributeFilename', 'file_name' => 'Help.txt']
        ]
    ],
    'message' => '[txt Help File](https://t.me/NEXTBOTchannel)',
    'parse_mode' => 'Markdown'
]);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "❄️NEXTBOTchannel-AntiSpam | Help :

▪️<code>راهنمای قفل</code>▪️  => راهنمای قفل ها
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>راهنمای مدیریت</code>▪️ => راهنمای مدیریتی
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>راهنمای فان</code>▪️ => راهنمای عمومی
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>راهنمای پاکسازی</code>▪️ => راهنمای پاکسازی
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>راهنمای سودو</code>▪️ => راهنمای سودو
🌧🌧🌧🌧🌧🌧🌧🌧🌧🌧🌧
کانال ما :
@NEXTBOTchannel",'reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
$sentMessage = $MadelineProto->messages->sendMedia([
    'peer' => $chatID,
    'media' => [
        '_' => 'inputMediaUploadedDocument',
        'file' => 'Help.txt',
        'attributes' => [
            ['_' => 'documentAttributeFilename', 'file_name' => 'Help.txt']
        ]
    ],
    'message' => '[txt Help File](https://t.me/NEXTBOTchannel)',
    'parse_mode' => 'Markdown'
]);
}
}
if($msg =="lockhelp" || $msg=="راهنمای قفل"){
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "🎗راهنمای بخش قفل ها :
https://t.me/NEXTBOTchannel
برای قفل ابتدای دستور عبارت lock و برای آزاد کردن قفل عبارت unlock را استفاده نمایید❕
نمونه :
<code>lock link</code>
بخش قفل ها شامل :
<b>[All , link , text , english , username , photo , document , mention . via , inline , voice , music , bot , forward , tg , contact , location , sticker , flood , tabchi]</b>
⚜️توجه کنید با قفل document رسانه به کلی قفل میشود(شامل گیف , آهنگ , ویس , فایل و...)⚜️
🌧🌧🌧🌧🌧🌧🌧🌧🌧🌧🌧
کانال ما :
@NEXTBOTchannel",'reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "🎗راهنمای بخش قفل ها :
https://t.me/NEXTBOTchannel
برای قفل ابتدای دستور عبارت (قفل) و برای آزاد کردن قفل عبارت (باز کردن) را استفاده نمایید❕
نمونه :
<code>قفل لینک</code>
بخش قفل ها شامل :
<b>[همه , لینک , متن , انگلیسی , یوزرنیم , عکس , رسانه , منشن . فراخوانی , دکمه شیشه ای , ویس , موزیک , ربات , فروارد , خدمات تلگرام , مخاطب , موقعیت مکانی , استیکر , اسپم , تبچی ]</b>
⚜️توجه کنید با قفل رسانه , رسانه به کلی قفل میشود(شامل گیف , آهنگ , ویس , فایل و...)⚜️
🌧🌧🌧🌧🌧🌧🌧🌧🌧🌧🌧
کانال ما :
@NEXTBOTchannel",'reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}
}
if($msg =="managehelp" || $msg=="راهنمای مدیریت"){
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "🎗راهنمای بخش مدیریتی :
https://t.me/NEXTBOTchannel
▪️<code>ping</code>▪️
▫️اطلاع از آنلاینی ربات▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>panel</code>▪️
▫️ورود به پنل مدیریتی شیشه ای ربات▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>settings</code>▪️
▫️دریافت تنظیمات گروه▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>config</code>▪️
▫️ارتقا همه ادمین های گروه به عنوان مدیر ربات▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>pin</code> [REPLY]▪️
▫️سنجاق کردن متن در گروه بوسیله ریپلی▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>unpin</code>▪️
▫️حذف پیام سنجاق شده در گروه▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>/setgroupname</code> [TEXT]▪️
▫️تغییر عنوان گروه▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>/setgroupdes</code> [TEXT]▪️
▫️تغییر توضیحات گروه▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>/setlang</code> [fa] | [en]▪️
▫️تغییر زبان ربات در گروه▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>/admins</code>▪️
▫️دریافت لیست ادمین ها▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>new link</code>▪️
▫️باطل کردن لینک قبلی و دریافت لینک جدید گروه▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>ban</code> [REPLY] | [USERNAME]▪️
▫️اخراج فرد از گروه▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>setwelcome</code> [TEXT]▪️
▫️تنظیم متن خوشامد به اعضای جدید و فعالسازی آن▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>welcome disable</code>▪️
▫️غیرفعال سازی متن خوشامد▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>mute</code> [REPLY] | [USERNAME]▪️
▫️بیصدا کردن فرد در گروه▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>mute for</code> [TIME-H] & [REPLY]▪️
▫️بیصدا کردن فرد در گروه به مدت زمان مشخص (ساعت) با ریپلی بروی پیام فرد▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>unmute</code> [REPLY] | [USERNAME]▪️
▫️باصدا کردن فرد در گروه▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>mute list</code>▪️
▫️دریافت لیست سکوت▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>filter</code> [TEXT]▪️
▫️فیلتر کردن کلمه در گروه▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>unfilter</code> [TEXT]▪️
▫️حذف کلمه از لیست فیلتر▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>filter list</code>▪️
▫️دریافت لیست فیلتر▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>warn</code> [USERNAME] | [REPLY]▪️
▫️اخطار دادن به فرد▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>unwarn</code> [USERNAME] | [REPLY]▪️
▫️حذف اخطار های فرد▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>setwarn</code> [1-50]▪️
▫️تنظیم حداکثر دریافت اخطار▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>/setflood</code> ️ [1-50]▪
▫️تنظیم زمان ارسال پیام مکرر▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>setlink</code> ️ [LINK]▪
▫️تنظیم لینک گروه برای همه کاربران▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>delete link</code>▪️ 
▫️حذف لینک تنظیم شده گروه برای همه کاربران▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>link</code>▪️ 
▫️دریافت لینک گروه برای همه کاربران▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>auto manage</code>▪️ 
▫️فعالسازی حالت قفل خودکار (قفل های ضروری فعال میشوند)▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>add</code> [on] | [off]▪️ 
▫️قابلیت افزودن ممبر برای تمامی اعضای گروه فعال باشد یا خیر▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>history</code> [on] | [off]▪️ 
▫️کاربرانی که تازه به گروه میپیوندند بتوانند پیام های قبلی گروه را مشاهده کنند یا خیر▫️
🌧🌧🌧🌧🌧🌧🌧🌧🌧🌧🌧
کانال ما :
@NEXTBOTchannel",'reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "🎗راهنمای بخش مدیریتی :
https://t.me/NEXTBOTchannel
▪️<code>ربات</code>▪️
▫️اطلاع از آنلاینی ربات▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>پنل</code>▪️
▫️ورود به پنل مدیریتی شیشه ای ربات▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>تنظیمات</code>▪️
▫️دریافت تنظیمات گروه▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>پیکربندی</code>▪️
▫️ارتقا همه ادمین های گروه به عنوان مدیر ربات▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>سنجاق</code> [ریپلی]▪️
▫️سنجاق کردن متن در گروه بوسیله ریپلی▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>حذف سنجاق</code>▪️
▫️حذف پیام سنجاق شده در گروه▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>تنظیم نام گروه</code> [متن]▪️
▫️تغییر عنوان گروه▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>تنظیم توضیحات گروه</code> [متن]▪️
▫️تغییر توضیحات گروه▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>زبان</code> [فارسی] | [انگلیسی]▪️
▫️تغییر زبان ربات در گروه▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>لیست ادمین ها</code>▪️
▫️دریافت لیست ادمین ها▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>باطل کردن لینک</code>▪️
▫️باطل کردن لینک قبلی و دریافت لینک جدید گروه▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>بن</code> [ریپلی] | [یوزرنیم]▪️
▫️اخراج فرد از گروه▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>تنظیم خوشامد</code> [متن]▪️
▫️تنظیم متن خوشامد به اعضای جدید و فعالسازی آن▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>حذف خوشامد</code>▪️
▫️غیرفعال سازی متن خوشامد▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>سکوت</code> [ریپلی] | [یوزرنیم]▪️
▫️بیصدا کردن فرد در گروه▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>سکوت برای</code> [زمان] & [ریپلی]▪️
▫️بیصدا کردن فرد در گروه به مدت زمان مشخص (ساعت) با ریپلی بروی پیام فرد▫️
??🔹🔸🔹🔸🔹🔸🔹
▪️<code>حذف سکوت</code> [ریپلی] | [یوزرنیم]▪️
▫️باصدا کردن فرد در گروه▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>لیست سکوت</code>▪️
▫️دریافت لیست سکوت▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>فیلتر کردن</code> [متن]▪️
▫️فیلتر کردن کلمه در گروه▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>حذف فیلتر</code> [متن]▪️
▫️حذف کلمه از لیست فیلتر▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>لیست فیلتر</code>▪️
▫️دریافت لیست فیلتر▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>اخطار دادن</code> [یوزرنیم] | [ریپلی]▪️
▫️اخطار دادن به فرد▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>حذف اخطار</code> [یوزرنیم] | [ریپلی]▪️
▫️حذف اخطار های فرد▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>تنظیم اخطار</code> [1-50]▪️
▫️تنظیم حداکثر دریافت اخطار▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>تنظیم فلود</code> ️ [1-50]▪
▫️تنظیم زمان ارسال پیام مکرر▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>تنظیم لینک</code> ️ [لینک گروه]▪
▫️تنظیم لینک گروه برای همه کاربران▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>حذف لینک</code>▪️ 
▫️حذف لینک تنظیم شده گروه برای همه کاربران▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>لینک گروه</code>▪️ 
▫️دریافت لینک گروه برای همه کاربران▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>تنظیمات خودکار</code>▪️ 
▫️فعالسازی حالت قفل خودکار (قفل های ضروری فعال میشوند)▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>ادد</code> [فعال] | [غیرفعال]▪️ 
▫️قابلیت افزودن ممبر برای تمامی اعضای گروه فعال باشد یا خیر▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>تاریخچه</code> [فعال] | [غیرفعال]▪️ 
▫️کاربرانی که تازه به گروه میپیوندند بتوانند پیام های قبلی گروه را مشاهده کنند یا خیر▫️
🌧🌧🌧🌧🌧🌧🌧🌧🌧🌧🌧
کانال ما :
@NEXTBOTchannel",'reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}
}
if($msg =="funhelp" || $msg=="راهنمای فان"){
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "🎗راهنمای بخش فان :
https://t.me/NEXTBOTchannel
▪️<code>id</code>▪️
▫️دریافت اطلاعات کاربر▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>translate</code> [Lang] & [REPLY]▪️
▫️ترجمه یک متن با ریپلی بروی آن و تعیین زبان مقصد▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>time</code>▪️
▫️دریافت ساعت در گروه▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>tofont</code> [TEXT]▪️
▫️فونت دار کردن متن شما▫️
🌧🌧🌧🌧🌧🌧🌧🌧🌧🌧🌧
کانال ما :
@NEXTBOTchannel",'reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "🎗راهنمای بخش فان :
https://t.me/NEXTBOTchannel
▪️<code>آیدی</code>▪️
▫️دریافت اطلاعات کاربر▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>ترجمه</code> [زبان] & [ریپلی]▪️
▫️ترجمه یک متن با ریپلی بروی آن و تعیین زبان مقصد▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>زمان</code>▪️
▫️دریافت ساعت در گروه▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>زیبانویس</code> [متن]▪️
▫️فونت دار کردن متن شما▫️
🌧🌧🌧🌧🌧🌧🌧🌧🌧🌧🌧
کانال ما :
@NEXTBOTchannel",'reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}
}
if($msg =="cleanhelp" || $msg=="راهنمای پاکسازی"){
if($lang == "en"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "🎗راهنمای بخش پاکسازی :
https://t.me/NEXTBOTchannel
▪️<code>/del</code> 1-500▪️
▫️حذف پیام های گروه▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>del</code> [REPLY]▪️
▫️حذف کل پیام های یک کاربر▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>clean msgs</code> [REPLY]▪️
▫️تلگرام و ربات های ضدلینک دارای محدودیت در حذف پیام هستند , گاهی ممکن است با روش قبل یعنی پاکسازی پیام با تعداد معین نتوانید از یک پیام خاص بالاتر را حذف کنید , با این دستور روی پیامی که از آن به بالا هیچ پیامی حذف نمیشود ریپلی کنید تا پاکسازی بطور کامل انجام شود▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>clear mute</code>▪️
▫️پاکسازی لیست سکوت▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>clear filter</code>▪️
▫️پاکسازی لیست فیلتر▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>clean bots</code>▪️
▫️حذف ربات های گروه▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>clean deleted</code>▪️
▫️حذف دیلیت اکانت های گروه▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>clear warn</code>▪️
▫️حذف لیست اخطار های گروه▫️
🌧🌧🌧🌧🌧🌧🌧🌧🌧🌧🌧
کانال ما :
@NEXTBOTchannel",'reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}else{
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "🎗راهنمای بخش پاکسازی :
https://t.me/NEXTBOTchannel
▪️<code>/del</code> 1-500▪️
▫️حذف پیام های گروه▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>پاکسازی</code> [رپلی]▪️
▫️حذف کل پیام های یک کاربر▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>پاکسازی پیام ها</code> [رپلی]▪️
▫️تلگرام و ربات های ضدلینک دارای محدودیت در حذف پیام هستند , گاهی ممکن است با روش قبل یعنی پاکسازی پیام با تعداد معین نتوانید از یک پیام خاص بالاتر را حذف کنید , با این دستور روی پیامی که از آن به بالا هیچ پیامی حذف نمیشود ریپلی کنید تا پاکسازی بطور کامل انجام شود▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>پاکسازی لیست سکوت</code>▪️
▫️پاکسازی لیست سکوت▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>پاکسازی لیست فیلتر</code>▪️
▫️پاکسازی لیست فیلتر▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>پاکسازی لیست اخطار</code>▪️
▫️حذف لیست اخطار های گروه▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>حذف ربات ها</code>▪️
▫️حذف ربات های گروه▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>حذف دلت اکانت ها</code>▪️
▫️حذف دیلیت اکانت های گروه▫️
🌧🌧🌧🌧🌧🌧🌧🌧🌧🌧🌧
کانال ما :
@NEXTBOTchannel",'reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}
}
}
if(in_array($userID,$admins)){
if($msg =="sudohelp" || $msg=="راهنمای سودو"){
$MadelineProto->messages->sendMessage(['peer' => $chatID,'message' => "❄️راهنمای مخصوص مدیریت (سودو) ضدلینک  :
https://t.me/NEXTBOTchannel
▪️<code>+</code>▪️
▫️روشن کردن ربات▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>-</code>▪️
▫️خاموش کردن ربات▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>نصب</code>▪️
▫️نصب کردن ربات در گروه▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>حذف گروه</code>▪️
▫️حذف کردن گروه از لیست مدیریتی ربات▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>ورود به</code>▪️[چت آیدی گروه]
▫️اضافه کردن شما در گروه مورد نظر▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>پاکسازی حافظه کش</code>▪️
▫️پاکسازی فایل های اضافی از هاست (سرور)▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>ریست ربات</code>▪️
▫️پاکسازی کل فایل ها و تنظیم مجدد ربات (پس از اجرای این دستور همه چیز پاک شده و باید از اول با دستور + ربات را روشن کنید!)▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>پیکربندی</code>▪️
▫️تنظیم همه ادمین های گروه به عنوان مدیر ربات▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>تنظیم مالک</code> [یوزرنیم] | [رپلی]▪️
▫️تنظیم صاحب گروه▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>تنظیم شارژ</code>▪️[1-999]
▫️تنظیم تاریخ انقضای ربات در گروه▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>BA</code>▪️ [ریپلی] | [یوزرنیم]
▫️سوپربن کردن فرد از تمام گروه های تحت پوشش ربات▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>UB</code>▪️ [ریپلی] | [یوزرنیم]
▫️پاکسازی فرد از لیست سوپربن▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>لیست بن آل</code>▪️
▫️لیست کردن لیست بن آل▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>پاکسازی لیست بن آل</code>▪️
▫️پاکسازی کل لیست سوپربن▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>دعوت به</code> [لینک گروه]▪️
▫️دعوت ربات به گروه با لینک▫️
〰〰〰〰〰〰〰〰〰〰
📍بخش مربوط به ارسال و فروارد :
⭕️بخش فروارد:
▪️<code>F2all</code>▪️ [ریپلی]
▫️فروارد یک پیام به تمامی گروه ها و اعضا و سوپرگروه ها▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>F2gps</code>▪️ [ریپلی]
▫️فروارد یک پیام به تمامی سوپرگروه ها▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>F2pv</code>▪️ [ریپلی]
▫️فروارد یک پیام به تمامی پیوی ها▫️
🔸🔹🔸🔹🔸🔹🔸🔹
⭕️بخش ارسال:
▪️<code>s2all</code>▪️ [متن]
▫️ارسال یک پیام به تمامی گروه ها و اعضا و سوپرگروه ها▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>s2sgps</code>▪️ [متن]
▫️ارسال یک پیام به تمامی سوپرگروه ها▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>s2pv</code>▪️ [متن]
▫️ارسال یک پیام به تمامی پیوی ها▫️
🔸🔹🔸🔹🔸🔹🔸🔹
▪️<code>stats</code>▪️
▫️دریافت تعداد کل گروه ها▫️
🍂🍂🍂🍂🍂🍂🍂🍂
این راهنما فقط مخصوص صاحبان ربات است(سودو ها)🌹

@NEXTBOTchannel",'reply_to_msg_id' => $msg_id,'parse_mode' => 'html']);
}
}
}
}
}
/*
@NEXTBOTchannel
https://t.me/NEXTBOTchannel
*/