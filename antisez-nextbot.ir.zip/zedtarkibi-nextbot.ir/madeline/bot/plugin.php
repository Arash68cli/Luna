<?php
/*
@NEXTBOTchannel
https://neXtbot.ir
*/
// ---
$admins = [
  480128879,
];
$web_url = "https://devmic.neXtgig.ir/Anti";
$helper_id = 'TESTBOT'; // ایدی ربات api
$support_id= '@SupremeArash'; // ایدی پشتیبان
// ---
$plugins = [
"tools",
"sudo",
"delete",
"send",
"help",
];
$cplug = count($plugins) - 1;
for($n=0; $n<=$cplug; $n++) {
  $pluginlist = "cli/".$plugins[$n].".php";
  include($pluginlist);
}
@$data=json_decode(file_get_contents('data.json'),true);
$power = $data['bot'];
unlink("MadelineProto.log");
/*
@NEXTBOTchannel
https://neXtbot.ir
*/