<?php
/*
انجمن ربات نویسی نکست بات
neXtbot.ir
*/
error_reporting(0);
if (!file_exists('madeline.php')) {
    copy('https://phar.madelineproto.xyz/madeline.php', 'madeline.php');
}
include 'madeline.php';
$MadelineProto = new \danog\MadelineProto\API('bot.madeline');
$MadelineProto->start();

header('content-type:application/json');
$type = $_GET['type'];
$gplink = $_GET['link'];
if($type == "join"){
$MadelineProto->channels->joinChannel(['channel' => "$gplink"]);
echo"ok";
}else{
echo"error";
}
/*
نکست بات
join in @NEXTBOTchannel
*/