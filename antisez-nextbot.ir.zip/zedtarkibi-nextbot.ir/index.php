<?php
/*
neXtbot supported
a code by devMic for forum
*/
ob_start();
define('API_KEY','TOKEN'); //توکن ربات
echo "Ready!"; //جهت مطلع شدن از مشکل نداشتن سورس
ini_set("log_errors","off");
date_default_timezone_set('Asia/Tehran');
function bot($method,$datas=[]){
$url = "https://api.telegram.org/bot".API_KEY."/".$method;
$ch = curl_init();
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
$res = curl_exec($ch);
if(curl_error($ch)){
var_dump(curl_error($ch));
}else{
return json_decode($res);
}
}
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$chat_id = $message->chat->id;
$message_id = $message->message_id;
$from_id = $message->from->id;
$text = $message->text;
$first_name = $message->from->first_name;
$last_name = $message->from->last_name;
$username = $message->from->username;
$data = json_decode(file_get_contents("data/$from_id"),true);
$step = $data["step"];
$grouplink = $data["gplink"];
function objectToArrays($object){
if(!is_object($object)&&!is_array($object)){
return $object;}
if(is_object($object)){
$object = get_object_vars($object);}
return array_map("objectToArrays",$object);}
if(!file_exists("data/$from_id")) {
$myfile2 = fopen("ID", "a") or die("Unable to open file!");
fwrite($myfile2, "$from_id\n");
fclose($myfile2);
$data["step"] = "";
$data["token"] = "";
$outjson = json_encode($data,true);
file_put_contents("data/$from_id",$outjson);
}
if($text == "/start" or $text == "بازگشت"){
$data["step"] = "";
$outjson = json_encode($data,true);
file_put_contents("data/$from_id",$outjson);
 bot('sendMessage',[
 'chat_id'=>$from_id,
 'text'=>"🙋‍♂سلام به ضدلینک نکست بات خوش اومدی.

🤖من یه ربات مدیریت گروه پیشرفته رایگان هستم و تو میتونی با من گروهتو مدیریت کنی!

🆕البته من کاملا رایگان و بدون تبلیغ هستیم.


😎و اینم بگم که من فقط ربات هلپر هستم و برای اینکه میخوای گروهتو مدیریت کنی باید از دکمه زیر استفاده کنی و لینک گروهتو بدی تا ربات دستیار (ربات اصلی) وارد گروهت بشه و مدیریت گروهتو شروع کنه.

خب شروع کن❤️👇",
 'parse_mode'=>"HTML",
 'reply_to_message_id'=>$message_id,
 'reply_markup'=>json_encode([
 'keyboard'=>[
[['text'=>'🆓>> نصب ربات']],
[['text'=>'▪️>> راهنما و درباره من']],
],
"resize_keyboard"=>true,
])
]);  
}
if($text == "▪️>> راهنما و درباره من"){
 bot('sendMessage',[
 'chat_id'=>$from_id,
 'text'=>"👇آموزش نصب ربات👇

1⃣روی دکمه نصب ربات کلیک کنید و لینک گروه خود را وارد کنید.

2⃣بعد از وارد کردن لینک، ربات اصلی وارد گروه شما می‌شود و شما میتوانید گروه خود را مدیریت کنید.

3⃣و فراموش نکنید راهنمای استفاده از ربات بعد از ارسال لینک برای شما ارسال می‌شود.
➖➖➖➖➖➖➖➖
👇آموزش دریافت لینک گروه 👇

1️⃣ وارد گروه شوید و روی نام گروه خود ضربه بزنید 
2️⃣ در منوی باز شده روی افزودن عضو ضربه بزنید
3️⃣ سپس روی بخش افزودن عضو با لینک ضربه بزنید و سپس کپی کردن لینک رو انتخاب کنید 
4️⃣ به ربات بازگشته و لینک گروه خود را ارسال کنید.
➖➖➖➖➖➖➖➖
🆔نویسنده سورس : @NEXTBOTchannel
✅کانال ما : @NEXTBOTchannel ",
 'parse_mode'=>"HTML",
 'reply_to_message_id'=>$message_id,
]); 
}
if($text == "🆓>> نصب ربات"){
$data["step"] = "getlink";
$outjson = json_encode($data,true);
file_put_contents("data/$from_id",$outjson);
 bot('sendMessage',[
 'chat_id'=>$from_id,
 'text'=>"▪️بسیار خوب دوست عزیز لطفا لینک گروه خود را ارسال کنید تا ربات اصلی وارد گروه شود.

🔙درصورتی که نیاز به راهنما دارید به منوی اصلی برگردید و از دکمه راهنما استفاده کنید.",
 'parse_mode'=>"HTML",
 'reply_to_message_id'=>$message_id,
 'reply_markup'=>json_encode([
 'keyboard'=>[
[['text'=>'بازگشت']],
],
"resize_keyboard"=>true,
])
]);  
}
elseif($text !== 'بازگشت' and $step == 'getlink'){
$data["gplink"] = "$text";
$data["step"] = "";
$outjson = json_encode($data,true);
file_put_contents("data/$from_id",$outjson);
//ادرس زیر، وب سرویس عضویت ربات در گروه است
$apiresult = file_get_contents("madeline/join/index.php?type=join&link=$grouplink");
if($apiresult == "ok"){
 bot('sendMessage',[
 'chat_id'=>$from_id,
 'text'=>"☑️ربات اصلی با موفقیت وارد گروه شما شد.

🙂هم اکنون میتوانید گروه خود را با استفاده از ربات ضد لینک اصلی مدیریت کنید.

⏺جهت دریافت راهنما، در گروه خود عبارت <b>help</b> را ارسال کنید.

🆔 @NEXTBOTchannel",
 'parse_mode'=>"HTML",
 'reply_to_message_id'=>$message_id,
 'reply_markup'=>json_encode([
 'keyboard'=>[
[['text'=>'بازگشت']],
],
"resize_keyboard"=>true,
])
]);
}else{
 bot('sendMessage',[
 'chat_id'=>$from_id,
 'text'=>"⛔️مشکلی در وارد شدن ربات cli به گروه بوجود آمد.
⚠️ممکن است لینک وارد شده اشتباه باشد یا ربات از قبل داخل گروه بوده است.

🔄لطفا دوباره سعی کنید...",
 'parse_mode'=>"HTML",
 'reply_to_message_id'=>$message_id,
 'reply_markup'=>json_encode([
 'keyboard'=>[
[['text'=>'بازگشت']],
],
"resize_keyboard"=>true,
])
]);
}
}
/*
@NEXTBOTchannel
https://neXtbot.ir
*/