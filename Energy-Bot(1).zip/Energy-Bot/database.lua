do local _ = {
  hash = {
    files = {},
    gifs = {},
    stickers = {},
    typing = {},
    values = {
      Amir = "جانم"
    }
  }
}
return _
end
